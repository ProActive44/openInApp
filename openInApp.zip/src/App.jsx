import './App.css'
import Dashboard from './pages/Dashboard'
import SignInPage from './pages/SignInPage'

function App() {

  return (
    <div className='h-[100%]'>
     {/* <SignInPage/> */}
     <Dashboard/>
    </div>
  )
}

export default App
